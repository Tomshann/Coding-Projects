<!DOCTYPE html>
<html>
<head>
<style>
ul {
list-style-type: none; margin:0;
padding-top: 0.4cm;
height: 0.7cm;
overflow: hidden;
background-color: blue;
}
li{
    float: right;
}
li a{
padding: 15px 20px;
text-align: center; font: Verdana;
font-size: 12px;
text-decoration: none;
color:white;
}
a:hover{
background-color:#ADD8E6;
}
</style>
</head>
<body>
<ul>
<li style="float: left;"><a name="home" href="index.php"><b>Home</b></a></li> 
<li><a name="register" href="registration.php"><b>Register</b></a></li>
<li><a name="memory" href="pairs.php"><b>Play Pairs</b></a></li>
</ul>
</body>
</html>