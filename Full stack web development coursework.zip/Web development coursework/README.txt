VM link to home page of coursework: http://ml-lab-4d78f073-aa49-4f0e-bce2-31e5254052c7.ukwest.cloudapp.azure.com:63984/index.php


index.php:
.completed all features in the specification

.navbar and background
.click here to play button
.not using registered session message/link

Pairs.php:
.completed all features of medium implementation:
.navbar
.start game button
.randomly generated emojis on the 10 cards shown
.card flip animations
.timer and moves counters
.submit score button that sends to leaderboard json file
.play again button

registration.php:
.completed all features of the complex implementation:
.allow users to create and customise an emoji avatar 
.exception for invalid character
.navbar
.stores the avatar to be added to the navbar on submission

Leaderboard.php:
completed full implementation:
.full design and layout to specification
.navbar
.loading leaderboard from json file so multiple users can see eachothers scores in the leaderboard
.scores formatted from highest to lowest
