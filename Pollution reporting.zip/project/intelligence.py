# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification

def find_red_pixels(*args,**kwargs):
    """Your documentation goes here"""
    # Your code goes here

def find_cyan_pixels(*args,**kwargs):
    """Your documentation goes here"""
    # Your code goes here


def detect_connected_components(*args,**kwargs):
    """Your documentation goes here"""
    # Your code goes here

def detect_connected_components_sorted(*args,**kwargs):
    """Your documentation goes here"""
    # Your code goes here

