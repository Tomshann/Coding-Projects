# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification


def main_menu():
    """Your documentation goes here"""
    # Your code goes here

def monitoring_menu():
    """Your documentation goes here"""
    # Your code goes here


def intelligence_menu():
    """Your documentation goes here"""
    # Your code goes here

def about():
    """Your documentation goes here"""
    # Your code goes here

def quit():
    """Your documentation goes here"""
    # Your code goes here




if __name__ == '__main__':
    main_menu()