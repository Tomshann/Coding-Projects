# This is a template. 
# You should modify the functions below to match
# the signatures determined by the project specification


def sumvalues(values):
    """Your documentation goes here"""    
    ## Your code goes here


def maxvalue(values):
    """Your documentation goes here"""    
    ## Your code goes here


def minvalue(values):
    """Your documentation goes here"""    
    ## Your code goes here


def meannvalue(values):
    """Your documentation goes here"""    
    ## Your code goes here


def countvalue(values,xw):
    """Your documentation goes here"""    
    ## Your code goes here
