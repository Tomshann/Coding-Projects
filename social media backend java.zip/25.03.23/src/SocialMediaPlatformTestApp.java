import socialmedia.*;

import java.io.IOException;

/**
 * A short program to illustrate an app testing some minimal functionality of a
 * concrete implementation of the SocialMediaPlatform interface -- note you will
 * want to increase these checks, and run it on your SocialMedia class (not the
 * BadSocialMedia class).
 *
 *
 * @author Diogo Pacheco
 * @version 1.0
 */
public class SocialMediaPlatformTestApp {

	/**
	 * Test method.
	 *
	 * @param args not used
	 */
	public static void main(String[] args) throws HandleNotRecognisedException {
		System.out.println("The system compiled and started the execution...");


		SocialMedia plat = new SocialMedia();

		assert (plat.getNumberOfAccounts() == 0) : "Innitial SocialMediaPlatform not empty as required.";
		assert (plat.getTotalOriginalPosts() == 0) : "Innitial SocialMediaPlatform not empty as required.";
		assert (plat.getTotalCommentPosts() == 0) : "Innitial SocialMediaPlatform not empty as required.";
		assert (plat.getTotalEndorsmentPosts() == 0) : "Innitial SocialMediaPlatform not empty as required.";


		Integer id;
		try {
			id = plat.createAccount("my_handle");
			int x = plat.createAccount("hi");
			plat.createPost("my_handle", "le bosh");
			plat.createPost("hi", "ok");
			plat.commentPost("hi", 0, "this is a commen");
			plat.commentPost("hi", 2, "this is a comment");
			plat.commentPost("hi", 0, "this is a commen");
			plat.commentPost("hi", 2, "this is a comment");

			plat.commentPost("hi", 2, "this is a comment");
			plat.endorsePost("hi", 0);
			plat.endorsePost("hi", 1);
			plat.endorsePost("hi", 0);


  			System.out.println(plat.showAccount("hi"));//this throws an exeption as no posts are created

			assert (plat.getNumberOfAccounts() == 1) : "number of accounts registered in the system does not match";
			System.out.println(plat.showIndividualPost(0));
			System.out.println(plat.showPostChildrenDetails(0));
		//
			plat.changeAccountHandle("hi", "poo");
			plat.updateAccountDescription("poo", "cristo ronaldo");
			System.out.println(plat.showAccount("poo"));

			System.out.println(plat.getTotalCommentPosts());
			System.out.println(plat.getTotalEndorsmentPosts());
			System.out.println(plat.getTotalOriginalPosts());
			plat.deletePost(0);
			System.out.println(plat.getMostEndorsedPost());
			plat.deletePost(2);

			plat.removeAccount(id);
			System.out.println(plat.getNumberOfAccounts());
			assert (plat.getNumberOfAccounts() == 0) : "number of accounts registered in the system does not match";

		//
			plat.savePlatform("test.ser");
			plat.erasePlatform();
			plat.loadPlatform("test.ser");
			//System.out.println(plat.showPostChildrenDetails(0));

			//
		} catch (IllegalHandleException e) {
			assert (false) : "IllegalHandleException thrown incorrectly";
		} catch (InvalidHandleException e) {
			assert (false) : "InvalidHandleException thrown incorrectly";
		} catch (AccountIDNotRecognisedException e) {
			assert (false) : "AccountIDNotRecognizedException thrown incorrectly";
		}
		catch (InvalidPostException e) {
			throw new RuntimeException(e);
		} catch (NotActionablePostException e) {
			throw new RuntimeException(e);
		}
		catch (PostIDNotRecognisedException e)
		{
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}


	}

}
